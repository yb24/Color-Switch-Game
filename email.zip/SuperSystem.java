import java.io.Serializable;
import java.util.ArrayList;

public class SuperSystem implements Serializable
{
    private static final long serialVersionUID = 42L;
    private int a;
    private String b;
    private Player currentPlayer;
    //private final ArrayList<Player> allPlayers;
    private final ArrayList<PlayerInfo> allPlayers;
    private final Leaderboard leaderboard;
    //private collision2 plsWork;
    private Game g;

    public SuperSystem()
    {
        this.a = 0;
        this.b = "default";
        this.currentPlayer = new Player();
        this.allPlayers = new ArrayList<>();
        this.leaderboard = new Leaderboard();
        this.g = new Game();
    }

    public void printDetails()
    {
        System.out.println("int a :" + a + " String b : " + b + " current player " + currentPlayer);
        System.out.println("All players:");
        for(PlayerInfo p: allPlayers)
        {
            p.printPlayerInfo();
        }
        System.out.println("Leaderboard:");
        displayLeaderboard();
    }

    public void setA(int a) {
        this.a = a;
    }

    public void setB(String b) {
        this.b = b;
    }

    public void setCurrentPlayer(Player p) {
        this.currentPlayer = p;
    }

    public Player getPlayerByIndex(int i)
    {
        if(i>=0 && i<allPlayers.size())
            return allPlayers.get(i).getPlayer();
        return null;
    }

    public void addPlayer(String name,boolean premiumStatus)
    {
        int id=0;
        for(PlayerInfo p: allPlayers)
        {
            id = Math.max(p.getPlayer().getID(),id);
        }
        id++;

        Player temp_player = new Player(name,id,premiumStatus);
        allPlayers.add(new PlayerInfo(temp_player));
        currentPlayer = temp_player;
    }

    public void removePlayer(int index)
    {
        allPlayers.remove(index);
    }

    public Player getCurrentPlayer()
    {
        return currentPlayer;
    }

    public void selectCurrentPlayer(int index)
    {
        currentPlayer = allPlayers.get(index).getPlayer();
    }

    public void newGame()
    {
        for(PlayerInfo p: allPlayers)
        {
            if(p.getPlayer()==currentPlayer)
            {
                p.addGame();
            }
        }
    }

    public void getSaveListOfCurrentPlayer(ArrayList<String> a)
    {
        for(PlayerInfo p: allPlayers)
        {
            if(p.checkEquality(currentPlayer))
            {
                p.forSaveListDisplay(a);
            }
        }
    }

    public void displayLeaderboard()
    {
        leaderboard.disp();
    }

    public void getAllPlayersString(ArrayList<String> a)
    {
        for(PlayerInfo p: allPlayers)
        {
            a.add(p.callGetPlayerString());
        }
    }

    public Game getG()
    {
        return g;
    }

    public void yy()
    {
        g.dispGamedetails();
    }

    public Leaderboard getLeaderboard()
    {
        return leaderboard;
    }

    public void tempFunc(String ts, int ti)
    {
        leaderboard.updateLeaderboard(ts,ti);
    }
}
