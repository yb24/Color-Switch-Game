import java.io.Serializable;
import java.util.ArrayList;

public class PlayerInfo implements Serializable
{
    private static final long serialVersionUID = 777L;
    private final Player thePlayer;
    private final ArrayList<DummyGame> savelist;

    public PlayerInfo()
    {
        thePlayer = new Player();
        savelist = new ArrayList<>();
    }

    public PlayerInfo(Player p)
    {
        thePlayer = p;
        savelist = new ArrayList<>();
    }

    public Player getPlayer()
    {
        return thePlayer;
    }

    public boolean checkEquality(Player other)
    {
        return thePlayer==other;
    }

    public String callGetPlayerString()
    {
        return thePlayer.getPlayerString();
    }

    public void forSaveListDisplay(ArrayList<String> a)
    {
        for(DummyGame dg: savelist)
        {
            a.add(dg.getDummyGameString());
        }
    }

    public void addGame()
    {
        int tempGameID=0;
        for(DummyGame dg: savelist)
        {
            tempGameID = Math.max(dg.getGameID(),tempGameID);
        }
        tempGameID++;

        savelist.add(new DummyGame(tempGameID,tempGameID*100));
    }

    public void printPlayerInfo()
    {
        System.out.println("thePlayer :" + thePlayer);
        System.out.println("saveList :");
        for(DummyGame dg: savelist)
        {
            dg.printDummyGameDetails();
        }
    }
}
