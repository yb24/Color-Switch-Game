public interface Loadable
{
    public void loadData();
}
