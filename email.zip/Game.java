import java.io.Serializable;
import java.util.ArrayList;

public class Game implements Serializable
{
    private static final long serialVersionUID = 7070L;
    private Ball ball;
    private ArrayList<Star> stars;
    private ArrayList<ColorChanger> colorChangers;

    Game()
    {
        ball = new Ball();
        stars = new ArrayList<>();
        colorChangers = new ArrayList<>();
    }

    public void dispGamedetails()
    {
        System.out.println(ball.getX());
        System.out.println(ball.getY());
    }

    public Ball getBall()
    {
        return ball;
    }



    public void abcd(double qq, double ww)
    {
        ball.updatePosition(qq,ww);
    }

    public double callGetX(Item i)
    {
        return i.getX();
    }

    public double callGetY(Item i)
    {
        return i.getY();
    }
}
