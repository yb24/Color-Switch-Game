import javafx.animation.*;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Bounds;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.ResourceBundle;

public class collision2 extends Application implements Initializable, Serializable {
    Obstacles obstacles;
    Random rand = new Random();
    ArrayList<object_animation> shapes;
    ArrayList<Timeline> timeline;
    Circle ball;
    int checker,a;
    boolean change=false;
    int star=0,score=0,col_changer=0;
    Text txf;
    Game tempG;

    public collision2()
    {
        tempG = Test.getObj().getG();
        obstacles=new Obstacles();
        shapes=new ArrayList<>();

        switch (tempG.getBall().getColorCodeOfBall())
        {
            case 1: ball = new Circle(tempG.callGetX(tempG.getBall()),tempG.callGetY(tempG.getBall()),5.0d,Color.RED);
                break;
            case 2: ball = new Circle(tempG.callGetX(tempG.getBall()),tempG.callGetY(tempG.getBall()),5.0d,Color.GREEN);
                break;
            case 3: ball = new Circle(tempG.callGetX(tempG.getBall()),tempG.callGetY(tempG.getBall()),5.0d,Color.BLUE);
                break;
            case 4: ball = new Circle(tempG.callGetX(tempG.getBall()),tempG.callGetY(tempG.getBall()),5.0d,Color.YELLOW);
                break;
            default: break;
        }
        checker=-1;
        a=0;
        change=false;
        star=0;
        score=0;
        col_changer=0;
    }

    private void checkShapeIntersection(Shape block,ArrayList<object_animation> shapes, Group root, Stage myStage) throws IOException {
        ArrayList<Shape> nodes=new ArrayList<>();
        int rm=0, star_struck =0,color_changer_struck=0;
        for(int i=0;i<shapes.size();i++) {
            for(int j=0;j<shapes.get(i).shape.getChildren().size();j++)
            {
                nodes.add((Shape) shapes.get(i).shape.getChildren().get(j));
            }
        }
        boolean collisionDetected = false;
        for (Shape static_bloc : nodes) {
            Shape intersect = Shape.intersect(block, static_bloc);
            if (intersect.getBoundsInLocal().getWidth() != -1) {
                if(static_bloc.getStroke()==block.getFill())
                {
                    collisionDetected = true;
                }
                else if(static_bloc.getStroke()==Color.BLACK)
                {
                    txf.setText(String.valueOf(++score));
                    star_struck =1;
                }
                else if(static_bloc.getStroke()==Color.DARKGREY)
                {
                    int rand_int=rand.nextInt(4);
                    switch (rand_int)
                    {
                        case 0: block.setFill(Color.YELLOW);
                                break;
                        case 1: block.setFill(Color.GREEN);
                                break;
                        case 2: block.setFill(Color.RED);
                            break;
                        case 3: block.setFill(Color.BLUE);
                            break;
                        default:break;
                    }
                    color_changer_struck=1;
                }
                else {
                    System.out.println("Crash "+(static_bloc.getStroke()==Color.WHITE));
                    Parent root2= FXMLLoader.load(getClass().getResource("obstacle_touched.fxml"));
                    Stage childStage =new Stage();
                    childStage.setScene(new Scene(root2));
                    childStage.initModality(Modality.APPLICATION_MODAL);
                    childStage.initOwner(myStage);
                    childStage.show();
                }
            }
            if(star_struck ==1) {
                rm = -1;
                for (int i = 0; i < shapes.size(); i++) {
                    if (shapes.get(i).shape.getChildren().get(0) instanceof Circle) {
                        rm = i;
                        break;
                    }
                }
                if (rm != -1) {
                    for (int i = 0; i < root.getChildren().size(); i++) {
                        if (root.getChildren().get(i).equals(shapes.get(rm).shape)) {
                            root.getChildren().remove(i);
                            i--;
                        }
                    }
                    object_animation h = shapes.remove(rm);
                    timeline.remove(rm);
                }
                star_struck =0;
            }
        }
        if(color_changer_struck ==1) {
            rm = -1;
            for (int i = 0; i < shapes.size(); i++) {
                if (shapes.get(i).shape.getChildren().get(0) instanceof Ellipse) {
                    rm = i;
                    break;
                }
            }
            if (rm != -1) {
                for (int i = 0; i < root.getChildren().size(); i++) {
                    if (root.getChildren().get(i).equals(shapes.get(rm).shape)) {
                        root.getChildren().remove(i);
                        i--;
                    }
                }
                object_animation h = shapes.remove(rm);
                timeline.remove(rm);
            }
            color_changer_struck = 0;
        }
    }

    public void shift_screen(double mag,Group root)
    {
        int rm=-1;
        double max=0;
        int flag=0;
        Bounds bound2=null,bound=null;
        for(int i=0;i<shapes.size();i++) {
            bound=shapes.get(i).shape.localToScene(shapes.get(i).shape.getBoundsInLocal());
            if(i>0)
            {
                if( (int) (bound2.getCenterY()-bound.getCenterY())>500)
                    flag = 1;
            }
            for(int j=0;j<shapes.get(i).shape.getChildren().size();j++)
            {
                if(shapes.get(i).shape.getChildren().get(j) instanceof Arc)
                {
                    Arc arc= (Arc) shapes.get(i).shape.getChildren().get(j);
                    arc.setCenterY(arc.getCenterY()+mag);
                }
                else if(shapes.get(i).shape.getChildren().get(j) instanceof Line)
                {
                    Line line= (Line) shapes.get(i).shape.getChildren().get(j);
                    line.setStartY(line.getStartY()+mag);
                    line.setEndY(line.getEndY()+mag);
                }
                else if(shapes.get(i).shape.getChildren().get(j) instanceof Circle)
                {
                    Circle cir= (Circle) shapes.get(i).shape.getChildren().get(j);
                    cir.setCenterY(cir.getCenterY()+mag);
                }
                else if(shapes.get(i).shape.getChildren().get(j) instanceof Ellipse)
                {
                    Ellipse elps= (Ellipse) shapes.get(i).shape.getChildren().get(j);
                    elps.setCenterY(elps.getCenterY()+mag);
                }
            }
            bound2 =shapes.get(i).shape.localToScene(shapes.get(i).shape.getBoundsInLocal());
            System.out.println((i+1)+" Bounds after translate "+(bound2.getCenterY()));
            if(bound.getCenterY()>=900) {
                System.out.println("to remove index: "+(i));
                rm=i;
                max=bound.getCenterY();
            }
        }
        if(rm!=-1) {
            //System.out.println("");
            for (int i = 0; i < root.getChildren().size(); i++) {
                System.out.println("root size: "+(root.getChildren().size()));
                System.out.println("i: "+(i));
                if (root.getChildren().get(i).equals(shapes.get(rm).shape)) {
                    root.getChildren().remove(i);
                    i--;
                }
            }
            object_animation h= shapes.remove(rm);
            timeline.remove(rm);
            System.out.println("size of shapes after removal: "+(shapes.size()));
        }
        if(max>=900)
        {
            object_animation obj;
            star++;
            col_changer++;
            if(flag==0)
                obj = obstacles.screen_obstacles(rand.nextInt(7)+1,0,0);
            else
                obj = obstacles.screen_obstacles(rand.nextInt(7)+1,-150,0);
            //star ka code
            if(star%4==0)
            {
                object_animation obj2;
                if(flag==0)
                    obj2 = obstacles.screen_obstacles(8,0,0);
                else
                    obj2 = obstacles.screen_obstacles(8,-150,0);
                bound = obj2.shape.localToScene(obj2.shape.getBoundsInLocal());
                root.getChildren().add(obj2.shape);
                timeline.add(new Timeline());
                shapes.add(obj2);
                checker = shapes.size() - 1;
                change = true;
                bound = obj2.shape.localToScene(obj2.shape.getBoundsInLocal());
                timeline.get(timeline.size() - 1).setCycleCount(Timeline.INDEFINITE);
                timeline.get(timeline.size() - 1).setAutoReverse(true);
                timeline.get(timeline.size() - 1).getKeyFrames().addAll(obj.animation);
                timeline.get(timeline.size() - 1).play();
                star=0;
            }
            if(col_changer%2==0)
            {
                object_animation obj2;
                if(flag==0)
                    obj2 = obstacles.screen_obstacles(9,-150,0);
                else
                    obj2 = obstacles.screen_obstacles(9,100,0);
                bound = obj2.shape.localToScene(obj2.shape.getBoundsInLocal());
                root.getChildren().add(obj2.shape);
                timeline.add(new Timeline());
                shapes.add(obj2);
                checker = shapes.size() - 1;
                change = true;
                bound = obj2.shape.localToScene(obj2.shape.getBoundsInLocal());
                timeline.get(timeline.size() - 1).setCycleCount(Timeline.INDEFINITE);
                timeline.get(timeline.size() - 1).setAutoReverse(true);
                timeline.get(timeline.size() - 1).getKeyFrames().addAll(obj.animation);
                timeline.get(timeline.size() - 1).play();
                col_changer=0;
            }
            bound = obj.shape.localToScene(obj.shape.getBoundsInLocal());
            root.getChildren().add(obj.shape);
            timeline.add(new Timeline());
            shapes.add(obj);
            checker = shapes.size() - 1;
            change = true;
            bound = obj.shape.localToScene(obj.shape.getBoundsInLocal());
            timeline.get(timeline.size() - 1).setCycleCount(Timeline.INDEFINITE);
            timeline.get(timeline.size() - 1).setAutoReverse(true);
            timeline.get(timeline.size() - 1).getKeyFrames().addAll(obj.animation);
            timeline.get(timeline.size() - 1).play();
            for (int i = 0; i < shapes.size(); i++) {
                bound = shapes.get(i).shape.localToScene(shapes.get(i).shape.getBoundsInLocal());
                System.out.println((i + 1) + "new list Bounds " + (bound.getCenterY()));
            }
        }
    }

    @Override
    public void start(Stage myStage) throws Exception {
        object_animation obj=obstacles.screen_obstacles(rand.nextInt(7) + 1,100,0);
        shapes.add(obj);
        object_animation obj2=obstacles.screen_obstacles(rand.nextInt(7) + 1,500,0);
        shapes.add(obj2);
        Image img = new Image(getClass().getResource("play.gif").toURI().toString());
        ImageView view = new ImageView(img);
        view.setFitHeight(80);
        view.setPreserveRatio(true);
        //Creating a Button
        Button button = new Button();
        //Setting the location of the button
        button.setTranslateX(20);
        button.setTranslateY(25);
        button.setStyle("-fx-background-color: #000000; ");
        //Setting the size of the button
        button.setPrefSize(80, 80);
        //Setting a graphic to the button
        button.setGraphic(view);
        txf=new Text();
        txf.setTranslateX(570);
        txf.setTranslateY(25);
        txf.setStyle("-fx-background-color: #000000;-fx-text-inner-color: red; ");
        txf.setFont(Font.font("Verdana",20));
        txf.setFill(Color.RED);
        txf.setText(String.valueOf((score)));

        timeline  = new ArrayList<>();
        Group root = new Group();
        //root.getChildren().addAll(obstacles,ball);
        int size=0;
        for(int i=0;i<shapes.size();i++) {
            root.getChildren().add(shapes.get(i).shape);
            timeline.add(new Timeline());
            timeline.get(i).setCycleCount(Timeline.INDEFINITE);
            timeline.get(i).setAutoReverse(true);
            timeline.get(i).getKeyFrames().addAll(shapes.get(i).animation);
            timeline.get(i).play();
            //timeline.getKeyFrames().add(shapes.get(i).animation);
        }
        System.out.println("Size of obstacle: "+(size));

        root.getChildren().add(ball);
        root.getChildren().add(button);
        root.getChildren().add(txf);
        Scene myScene = new Scene(root,600,800,Color.BLACK);
        myStage.setScene(myScene);
        myStage.setTitle("Gameplay Animation");
        myStage.show();
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Parent root2= null;
                try {
                    root2 = FXMLLoader.load(getClass().getResource("pause_game.fxml"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Stage childStage =new Stage();
                childStage.setScene(new Scene(root2));
                childStage.initModality(Modality.APPLICATION_MODAL);
                childStage.initOwner(myStage);
                childStage.show();
                shift_screen( 900.0d-ball.getCenterY(),root);
                ball.setCenterY(900.0d);
                tempG.abcd(ball.getCenterX(),900.0d);
                System.out.print(ball.getCenterY());
            }
        });
        myScene.setOnKeyPressed(e-> {
            if (e.getCode() == KeyCode.W) {
                KeyValue xValue  = new KeyValue(ball.centerYProperty(), 800);
                KeyFrame keyFrame2  = new KeyFrame(Duration.millis((900-ball.getCenterY())*20), xValue);
                Timeline timeline2  = new Timeline();
                timeline2.setCycleCount(1);
                timeline2.getKeyFrames().addAll(keyFrame2);
                ball.setCenterY(ball.getCenterY() - 20);
                tempG.abcd(ball.getCenterX(),ball.getCenterY());
                try {
                    checkShapeIntersection(ball,shapes,root,myStage);
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
                if(ball.getCenterY()<=400) {
                    System.out.println("hi");
                    shift_screen( 20,root);
                    ball.setCenterY(400);
                    tempG.abcd(ball.getCenterX(),ball.getCenterY());
                }
                timeline2.play();
            }
        });
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
