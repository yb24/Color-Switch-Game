import java.io.Serializable;

public class ColorChanger extends Consumables implements Serializable
{
    ColorChanger(double x, double y)
    {
        super(x,y,false);
    }
}
